package com.cg.demoforspringangular.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.demoforspringangular.bean.Customer;
import com.cg.demoforspringangular.service.CustomerService;

//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/bookstore")

@CrossOrigin(origins="http://localhost:4200")   
public class Controller {

	@Autowired
	CustomerService customerService;
	
	
	
	@GetMapping("/register/{name}/{email}/{mobile}/{password}")
	public boolean createNewCustomerProfile(@PathVariable("name")String name,@PathVariable("email")String email,@PathVariable("mobile")String mobile,@PathVariable("password")String password) {
		
		
		System.out.println(name+"   "+email+"  ");
		
		Customer newCudtomer = new Customer(name, mobile, password, email);
		return customerService.createcustomer(newCudtomer);
		
		
		
	}
	
	
	@RequestMapping(value = "/viewprofile/{mobile}", method = RequestMethod.GET,headers = "Accept=application/json",produces = MediaType.APPLICATION_JSON_VALUE)
	public Customer viewCustomerProfile(@PathVariable("mobile")String mobile) {
		System.err.println(customerService.getCustomer(mobile));
		return customerService.getCustomer(mobile);
		
		
		
	}
	
	/*
	 * @CrossOrigin(origins="http://localhost:4200") // @CrossOrigin is used to
	 * handle the request from a difference origin.
	 * 
	 * @GetMapping("/viewprofile/{mobile}") public Customer
	 * viewCustomerProfile(@PathVariable("mobile")String mobile) {
	 * 
	 * return customerService.getCustomer(mobile);
	 * 
	 * 
	 * 
	 * }
	 */
	
	                  // @CrossOrigin is used to handle the request from a difference origin.
	    @RequestMapping("/getall") 
	public List<Customer> getAllCustomers(){
	
		List<Customer> clist = 	customerService.findAll();	
		System.out.println(	clist);
		
	return 	clist;
		
	}
	
	
	
}
