package com.cg.demoforspringangular.service;

import java.util.List;

import com.cg.demoforspringangular.bean.Customer;

public interface CustomerService {

public boolean createcustomer(Customer c);
	
	public boolean updatecustomer(Customer c);
	
	public Customer getCustomer(String mobile);
	 
	public List<Customer> getAllCustomers();
	
	
	public List<Customer> findAll();
	
	
}
