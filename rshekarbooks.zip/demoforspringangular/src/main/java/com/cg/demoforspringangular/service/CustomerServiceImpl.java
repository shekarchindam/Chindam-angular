package com.cg.demoforspringangular.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demoforspringangular.bean.Customer;
import com.cg.demoforspringangular.dao.CustomerDao;

@Service("customerService")
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	CustomerDao customerDao;
	
	@Override
	public boolean createcustomer(Customer c) {
		
		if(c!=null) {
		customerDao.save(c)	;
		
		return true;
			
		}
		
		return false;
	}

	@Override
	public boolean updatecustomer(Customer c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomer(String mobile) {
		Customer getCustomer = customerDao.findBycustomerMobile(mobile);
	
		System.out.println("--------------    "+getCustomer);
		if(getCustomer!=null) {
			return getCustomer;
			
		}
		return getCustomer;
	}

	@Override
	public List<Customer> getAllCustomers() {
		List<Customer> allCustomers = customerDao.findAll();
		return allCustomers;
	}

	@Override
	public List<Customer> findAll() {
		// TODO Auto-generated method stub
		return customerDao.findAll();
	}
	
	
}
