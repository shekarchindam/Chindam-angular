package com.cg.demoforspringangular.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="angulardemocustomer")
public class Customer {
	
	@Id
	private int id;
	@Column(name="name")
	private String customerName;
	
	@Column(name="mobile")
	private String customerMobile;
	
	@Column(name="password")
	private String customerPassword;
	
	@Column(name="email")
	private String customerEmail;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
	
	
	public Customer(String customerName, String customerMobile, String customerPassword, String customerEmail) {
		super();
		this.customerName = customerName;
		this.customerMobile = customerMobile;
		this.customerPassword = customerPassword;
		this.customerEmail = customerEmail;
	}





	@Override
	public String toString() {
		return "Customer [id=" + id + ", customerName=" + customerName + ", customerMobile=" + customerMobile
				+ ", customerPassword=" + customerPassword + ", customerEmail=" + customerEmail + "]";
	}





	
	
	
}
