import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'mybookstoreapp';
  
    // Object to save the response returned from the service.
  myresponse: any;
 
  // Url to fetch the customer records from the spring application.
  readonly APP_URL = 'http://localhost:8099/bookstore/getall';
 
  constructor(private _http: HttpClient) { }
 
  // Method to fetch all customers from the database table.
  getall() {
    this._http.get(this.APP_URL + '/getall').subscribe(
      data => {
        this.myresponse = data;
      },
      error => {
        console.log('Error occured', error);
      }
    );
  }
}
